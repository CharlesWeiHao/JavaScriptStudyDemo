// alert('Hello JavaScript');

/** --------------------- if else -------------------- */

// if - else 使用
// var weather = '晴天';
// if (weather == '晴天') {
// 	alert('心情不错');
// } else {
// 	alert('心情糟糕');
// }

/** --------------------- switch -------------------- */

// switch 使用
// var sex = 'man';
// switch (sex) {

// 	case 'man':
// 	console.log('man');
// 	break;

// 	case 'woman':
// 	console.log('woman');
// 	break;

// 	case 'unknow':
// 	console.log('unknow');
// 	break;

// 	default :
// 	console.log('default');
// 	break;
// }

/** --------------------- while -------------------- */ 

// while 循环使用
// var i = 0;
// while (i < 10) {
// 	i ++;

// 	if (i % 2 == 0) {
// 		continue;
// 	}
// 	console.log(i);
// }

/** --------------------- for -------------------- */ 
// for循环使用
// for (i = 0; i < 10 ; i++) {
// 	console.log('i -> '+i);
// }

// for 循环遍历数组
// var weakArr = ['星期一','星期二','星期三','星期四','星期五','星期六','星期日'];
// for (let i = 0; i < weakArr.length; i ++) {
// 	console.log(weakArr[i]);
// }

/** --------------------- function -------------------- */

// 无参数
// function alertMessage () {
// 	alert ('无参数 - function');
// }
// 函数调用
// alertMessage ();

// 带参数
// function alertMessage (message) {
// 	alert (message);
// }
// 函数调用
// alertMessage ('带参数 - function');

// 匿名函数调用
// var alertMessage = function (message) {
// 	alert(message);
// }

// alertMessage ('匿名函数调用');

// 定义函数外面变量
// var message = '定义函数外面变量';

// function alertMessage () {
// 	alert(message);
// }

// alertMessage ();


// 定义函数内部变量
// var alertMessage = function () {
// 	var message = '定义函数内部变量';
// 	alert (message);
// }

// alertMessage ();


/** --------------------- object -------------------- */

// property (属性)
// method （方法）

// 创建类的方式一：
// var beyond = {};
// // 点语法 和 方括号 设置属性
// beyond.formedIn = '1983';
// beyond['foundedIn'] = 'HongKong'; 
// console.log(beyond);

// 创建类的方式二：
// var beyond = {formedIn : '1983', foundedIn : 'HongKong'};
// console.log(beyond);

 // 类中包含数组
// var beyond = { 
//  	formedIn : '1983', 
//  	foundedIn : 'HongKong',
//   	artist : ['黄家驹', '黄家强', '黄贯中', '叶世荣']
// };
// console.log (beyond);

// 替换对象中的某个属性
// beyond.foundedIn = 'China HongKong';
// console.log(beyond);

// 移除对象中的某个属性
// delete beyond.foundedIn;
// console.log(beyond);

// 给对象添加方法
// beyond.showArtist = function () {
// 	for (i = 0; i < this.artist.length; i ++) {
// 		// console.log (this.artist[i]);
// 		// 显示到网页
// 		document.writeln(this.artist[i]);
// 	}
// }
// beyond.showArtist ();

// for in 循环遍历对象的属性
// var property;
// for (property in beyond) {
// 	// console.log(property);
// 	// 不输入对象的方法
// 	if (typeof beyond[property] !== 'function') {
// 		console.log(beyond[property]);
// 	}
// }


/** --------------------- DOM -------------------- */
// 文档对象模型 DOM （Document Object Model）

// 文档树 （DOM Tree） 在 ‘index.html’ 文件中有示例

/** --------------------- touch -------------------- */

// 在 ‘index.html’ 定义个一个 <a> 标签 , 在此定义事件 , 注意方法名是小写
// 在window加载完成之后，再执行
// window.onload = function () {
// 	var btn = document.querySelector('.btn');

	// 点击事件
// 	btn.onclick = function () {
// 		console.log('onClick');
// 	}

// 	// 鼠标滑动到按钮的事件
// 	btn.onmouseover = function () {
// 		console.log('onmouseover');
// 	}

// 	// 鼠标离开按钮的事件
// 	btn.onmouseout = function () {
// 		console.log ('onmouseout');
// 	}
// }

// 给对象绑定事件
// window.onload = function () {
// 	var btn = document.querySelector('.btn');

// 	// 实现添加的事件
// 	function showMessage (event) {
// 		console.log('clicked!');
// 		// 打印事件对象
// 		// console.log(event);
// 	}

// 	/**
// 		click : 绑定事件的名称
// 		showMessage ：执行事件的名称
// 		false：捕获事件，默认是false ，不捕获事件
// 	*/ 
// 	btn.addEventListener('click', showMessage , false);
// }

/** --------------------- Event Propagation -------------------- */

// 事件传播
var listGourp = document.querySelector('.list-group');

function showListMessage (event) {
	// 打印事件对象
	// console.log(event.target.alt);

	console.log('click ul event');

	// 停止事件传递,
	event.stopPropagation();

}
// true：捕获事件，默认是false ，表示捕获事件
listGourp.addEventListener('click', showListMessage , true);

// 捕获事件
var shopcart = document.getElementById('shopcartid');
function shopcartClick () {
	console.log('click shopcartClick');
}
shopcart.addEventListener('click', shopcartClick, false);








